# Photo-derived character layers

These original imagegen assets replace the block-style avatar in Dreamio's Dressing Room. Every raster layer uses a **1024 × 1536 transparent RGBA canvas** and a common origin. The original real-world photo is not shipped as a site asset.

| File                      | Purpose                                                                                                                     |
| ------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `original.png`            | Canonical isolated character, retaining the generated face, hair, selfie pose, cat ears, wings, black dress and wrist cuff. |
| `body.png`                | Covered base character in a modest opaque lavender unitard, including the original hair, face, arms and phone pose.         |
| `wings.png`               | Separate black feather wings, behind the body.                                                                              |
| `dress.png`               | Black corset dress and layered skirt. The UI offers original black, lavender and rose color treatments.                     |
| `tights.png`              | Fishnet thigh layer, independently switchable.                                                                              |
| `ears.png`                | Cat-ear headband, independently switchable.                                                                                 |
| `cuffs.png`               | Silver studded wrist cuff, independently switchable.                                                                        |
| `generation-prompts.json` | Final generation prompts and compositor notes.                                                                              |

## Composition

`src/components/layered-character.tsx` composes the artwork as SVG `<image>` layers in this order: wings → covered base → tights → dress → foreground → cat ears → cuff. The foreground reuses `original.png` with an SVG luminance mask built from the separated layer alpha channels, keeping the original hair, face, neck, phone and visible arms in front of the clothes. It does not use a separately generated foreground file.

The tights layer is stretched vertically by 12.5%, anchored at the top of the tights, to cover the complete original thigh crop. The lowered-hand mask preserves its original overlap over the skirt. These are display transforms; the original generated PNGs are retained unchanged.

Main character, head portrait and small outfit preview share one `CharacterLook`. Its switches and dress color persist locally under `dreamio-photo-character-v1`. The reset button restores the original black outfit and all original accessories. The character is intentionally cropped above the knees; no footwear or body below the supplied crop is invented.

This is one prepared photo-derived character with registered artwork layers. Automatically generating a new layered character from a website upload and fitting arbitrary shop items onto this character are separate future capabilities. Shop inventory and this character's included layer controls currently have separate local state.
