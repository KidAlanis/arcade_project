"use client";
import { useEffect, useId, useRef, useState } from "react";
import {
  characterLayers,
  dressColors,
  originalCharacterLook,
  restoreCharacterLook,
  type CharacterLayer,
  type CharacterLook,
} from "@/lib/character";

const KEY = "dreamio-photo-character-v1";
export function useCharacterLook() {
  const [look, setLook] = useState<CharacterLook>({ ...originalCharacterLook });
  const [ready, setReady] = useState(false);
  const [storageAvailable, setStorageAvailable] = useState(true);
  const current = useRef(look);
  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) current.current = restoreCharacterLook(raw);
    } catch {
      setStorageAvailable(false);
    }
    setLook(current.current);
    setReady(true);
    const sync = (event: StorageEvent) => {
      if (event.key !== KEY) return;
      current.current = event.newValue
        ? restoreCharacterLook(event.newValue)
        : { ...originalCharacterLook };
      setLook(current.current);
    };
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);
  function update(change: Partial<CharacterLook>) {
    if (!ready) return;
    const next = { ...current.current, ...change, version: 1 as const };
    current.current = next;
    setLook(next);
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      setStorageAvailable(false);
    }
  }
  return {
    look,
    ready,
    storageAvailable,
    update,
    reset: () => update({ ...originalCharacterLook }),
  };
}
export function LayeredCharacter({
  look,
  portrait = false,
  className = "",
}: {
  look: CharacterLook;
  portrait?: boolean;
  className?: string;
}) {
  const id = useId().replace(/:/g, "");
  const foregroundMask = `${id}-foreground`;
  const whiteAlpha = `${id}-white-alpha`;
  const blackAlpha = `${id}-black-alpha`;
  const filter = dressColors.find(
    (color) => color.id === look.dressColor,
  )!.filter;
  return (
    <svg
      className={className}
      viewBox={portrait ? "260 30 500 560" : "0 0 1024 1536"}
      preserveAspectRatio={portrait ? "xMidYMin slice" : "xMidYMax meet"}
      role="img"
      aria-label={
        portrait
          ? "Portrait of your photo-based character"
          : "Your photo-based character with layered outfit"
      }
    >
      <defs>
        <filter id={whiteAlpha} colorInterpolationFilters="sRGB">
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 1 0"
          />
        </filter>
        <filter id={blackAlpha} colorInterpolationFilters="sRGB">
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0"
          />
        </filter>
        <mask
          id={foregroundMask}
          maskUnits="userSpaceOnUse"
          x="0"
          y="0"
          width="1024"
          height="1536"
          style={{ maskType: "luminance" }}
        >
          <image
            href="/art/character/body.png"
            width="1024"
            height="1536"
            filter={`url(#${whiteAlpha})`}
          />
          {["dress", "ears", "cuffs"].map((layer) => (
            <image
              key={layer}
              href={`/art/character/${layer}.png`}
              width="1024"
              height="1536"
              filter={`url(#${blackAlpha})`}
            />
          ))}
          <rect x="320" y="1190" width="520" height="346" fill="black" />
          <path
            d="M258 1047 L315 1065 L301 1120 L310 1185 L289 1231 L260 1259 L223 1239 L201 1207 L204 1165 Z"
            fill="white"
          />
        </mask>
      </defs>
      {characterLayers
        .filter(
          (layer) =>
            layer.id === "body" || layer.id === "foreground" || look[layer.id],
        )
        .map((layer) => (
          <image
            key={layer.id}
            data-character-layer={layer.id}
            href={layer.src}
            x="0"
            y="0"
            width="1024"
            height="1536"
            transform={
              layer.id === "tights"
                ? "translate(0 -153) scale(1 1.125)"
                : undefined
            }
            mask={
              layer.id === "foreground" ? `url(#${foregroundMask})` : undefined
            }
            style={layer.id === "dress" ? { filter } : undefined}
          />
        ))}
    </svg>
  );
}
export function CharacterLayerArt({
  layer,
  color = "original",
}: {
  layer: CharacterLayer;
  color?: CharacterLook["dressColor"];
}) {
  const asset = characterLayers.find((item) => item.id === layer)!;
  return (
    <svg
      viewBox={asset.crop}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      <image
        href={asset.src}
        width="1024"
        height="1536"
        style={
          layer === "dress"
            ? {
                filter: dressColors.find((option) => option.id === color)!
                  .filter,
              }
            : undefined
        }
      />
    </svg>
  );
}
