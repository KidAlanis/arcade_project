export type CharacterLayer =
  "body" | "wings" | "dress" | "tights" | "foreground" | "ears" | "cuffs";
export type DressColor = "original" | "lavender" | "rose";
export type CharacterLook = {
  version: 1;
  dress: boolean;
  wings: boolean;
  tights: boolean;
  ears: boolean;
  cuffs: boolean;
  dressColor: DressColor;
};
export const originalCharacterLook: CharacterLook = {
  version: 1,
  dress: true,
  wings: true,
  tights: true,
  ears: true,
  cuffs: true,
  dressColor: "original",
};
export const characterLayers: {
  id: CharacterLayer;
  name: string;
  src: string;
  crop: string;
}[] = [
  {
    id: "wings",
    name: "Black Feather Wings",
    src: "/art/character/wings.png",
    crop: "0 320 1024 470",
  },
  {
    id: "body",
    name: "Original Photo Character",
    src: "/art/character/body.png",
    crop: "270 30 500 560",
  },
  {
    id: "tights",
    name: "Lace Fishnet Tights",
    src: "/art/character/tights.png",
    crop: "300 1220 520 316",
  },
  {
    id: "dress",
    name: "Black Corset Dress",
    src: "/art/character/dress.png",
    crop: "260 560 610 800",
  },
  {
    id: "foreground",
    name: "Hair, Face and Selfie Pose",
    src: "/art/character/original.png",
    crop: "270 30 500 560",
  },
  {
    id: "ears",
    name: "Black Cat Ears",
    src: "/art/character/ears.png",
    crop: "300 30 440 190",
  },
  {
    id: "cuffs",
    name: "Silver Studded Cuff",
    src: "/art/character/cuffs.png",
    crop: "200 940 170 170",
  },
];
export const dressColors: {
  id: DressColor;
  name: string;
  color: string;
  filter: string;
}[] = [
  { id: "original", name: "Original Black", color: "#37313f", filter: "none" },
  {
    id: "lavender",
    name: "Lavender Corset",
    color: "#a999d4",
    filter: "brightness(2.1) sepia(.65) saturate(1.7) hue-rotate(208deg)",
  },
  {
    id: "rose",
    name: "Rose Corset",
    color: "#cc98b5",
    filter: "brightness(2) sepia(.7) saturate(1.7) hue-rotate(287deg)",
  },
];
export function restoreCharacterLook(raw: string): CharacterLook {
  try {
    const value = JSON.parse(raw);
    if (!value || value.version !== 1) return { ...originalCharacterLook };
    const look = { ...originalCharacterLook };
    for (const key of ["dress", "wings", "tights", "ears", "cuffs"] as const) {
      if (typeof value[key] === "boolean") look[key] = value[key];
    }
    if (dressColors.some((color) => color.id === value.dressColor))
      look.dressColor = value.dressColor;
    return look;
  } catch {
    return { ...originalCharacterLook };
  }
}
